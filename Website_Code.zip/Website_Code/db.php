<?php
	$con = mysqli_connect('localhost', 'root', '', 'event_apa');
	// Check connection
	if (!$con) {
		die("Connection failed: " . mysqli_connect_error());
	}
?>
